const menuToggle=document.querySelector(".menu-toggle");
const nav=document.querySelector(".primary-nav");
if(menuToggle&&nav){
  menuToggle.addEventListener("click",()=>{
    const open=nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded",String(open));
    document.body.classList.toggle("menu-open",open);
  });
  nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{
    nav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded","false");
    document.body.classList.remove("menu-open");
  }));
}

const reveals=document.querySelectorAll(".reveal");
if("IntersectionObserver" in window){
  const observer=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("visible");observer.unobserve(entry.target)}})
  },{threshold:.12});
  reveals.forEach(el=>observer.observe(el));
}else reveals.forEach(el=>el.classList.add("visible"));

const deadlineForm=document.querySelector("#deadline-form");
const toast=document.querySelector("#toast");
function showToast(message){
  if(!toast)return;
  toast.textContent=message;
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer=setTimeout(()=>toast.classList.remove("show"),3500);
}
if(deadlineForm){
  deadlineForm.addEventListener("submit",e=>{
    e.preventDefault();
    const days=Math.max(1,Math.min(180,Number(new FormData(deadlineForm).get("days"))||10));
    showToast(`We'll prioritize the essentials for a ${days}-day timeline. Start your profile to continue.`);
  });
}

document.querySelectorAll("[data-accordion] details").forEach(detail=>{
  detail.addEventListener("toggle",()=>{
    if(detail.open){
      document.querySelectorAll("[data-accordion] details").forEach(other=>{
        if(other!==detail) other.removeAttribute("open");
      });
    }
  });
});
