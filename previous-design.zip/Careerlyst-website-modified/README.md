# Careerlyst website — vanilla HTML/CSS/JS

Working brand name: Careerlyst. Replace with your final approved brand name.

## Run
Open `index.html` directly in a browser, or serve the folder with any static server.

## Pages
- index.html
- services.html
- pricing.html
- about.html
- contact.html
- privacy.html
- terms.html
- refund.html

## Notes
- No framework, Tailwind, Bootstrap, jQuery or build step.
- Google Fonts are loaded as the only external visual dependency.
- Contact form is demo-only and must be connected to a real backend/form provider.
- Pricing is launch/test pricing and should be validated.
- Legal pages are starter placeholders and need jurisdiction-specific review before launch.


## Hero image
The homepage hero now uses `assets/images/hero-illustration.png` as a real image asset.
The hero copy, buttons, and navigation remain HTML/CSS so the site stays responsive and editable.

## Local preview
Serve the project from its root directory rather than opening `index.html` through a `content://` file viewer:

`python -m http.server 8080`

Then open `http://localhost:8080`.
